import torch
import torch.nn as nn
from torchvision.models.segmentation import deeplabv3_resnet50


# ---------------------------------------------------------
# DeepLabV3 (ResNet-50 backbone)
# ---------------------------------------------------------
def get_deeplab(num_classes=19):
    model = deeplabv3_resnet50(weights="DEFAULT")
    model.classifier[-1] = nn.Conv2d(256, num_classes, kernel_size=1)
    return model


# ---------------------------------------------------------
# Fast-SCNN (lightweight real-time segmentation)
# ---------------------------------------------------------
class FastSCNN(nn.Module):
    # Extremely compact real-time semantic segmentation model.
    # This is a standard implementation used in tutorials/projects.
    def __init__(self, num_classes=19):
        super().__init__()

        # Learning downsample block
        self.down = nn.Sequential(
            nn.Conv2d(3, 32, 3, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),

            nn.Conv2d(32, 48, 3, stride=2, padding=1),
            nn.BatchNorm2d(48),
            nn.ReLU(inplace=True),

            nn.Conv2d(48, 64, 3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )

        # Global feature extractor (simplified)
        self.global_feat = nn.Sequential(
            nn.Conv2d(64, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),

            nn.Conv2d(128, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )

        # Classifier
        self.classifier = nn.Conv2d(128, num_classes, 1)

        # Simple upsampling
        self.up = nn.Upsample(scale_factor=8, mode="bilinear", align_corners=False)

    def forward(self, x):
        x = self.down(x)
        x = self.global_feat(x)
        x = self.classifier(x)
        x = self.up(x)
        return {"out": x}


def get_fastscnn(num_classes=19):
    return FastSCNN(num_classes=num_classes)


# ---------------------------------------------------------
# BiSeNetV2 (lightweight + good accuracy)
# ---------------------------------------------------------
# Note: This is a clean minimal version used in many courses/projects.
class BiSeNetV2(nn.Module):
    def __init__(self, num_classes=19):
        super().__init__()

        # Detail branch (high-resolution)
        self.detail = nn.Sequential(
            nn.Conv2d(3, 64, 3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, 3, padding=1),
            nn.ReLU(inplace=True),

            nn.Conv2d(64, 128, 3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, 3, padding=1),
            nn.ReLU(inplace=True)
        )

        # Semantic branch (context)
        self.semantic = nn.Sequential(
            nn.Conv2d(3, 16, 3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 32, 3, stride=2, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, stride=2, padding=1),
            nn.ReLU(inplace=True)
        )

        # Fusion
        self.fusion = nn.Conv2d(128 + 64, 256, 1)

        # Classifier
        self.classifier = nn.Conv2d(256, num_classes, 1)

        self.up = nn.Upsample(scale_factor=8, mode="bilinear", align_corners=False)

    def forward(self, x):
        d = self.detail(x)
        s = self.semantic(x)

        # Resize semantic to match detail
        s_up = torch.nn.functional.interpolate(s, size=d.shape[2:], mode="bilinear")

        fused = torch.cat([d, s_up], dim=1)
        fused = self.fusion(fused)

        out = self.classifier(fused)
        out = self.up(out)
        return {"out": out}


def get_bisenetv2(num_classes=19):
    return BiSeNetV2(num_classes=num_classes)
